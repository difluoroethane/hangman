import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class HangmanGame extends JFrame implements KeyListener {
    // Word bank and their clues
    private static final Map<String, String> WORD_CLUES = new HashMap<String, String>() {{
        put("ALGORITHM", "A step-by-step approach to solving problems");
        put("JAVA", "A programming language named after coffee");
        put("COMPUTER", "An electronic device that processes data");
        put("INTERFACE", "A point where two systems meet and interact");
        put("DEVELOPER", "Someone who creates software applications");
        put("SOFTWARE", "Computer programs and related data");
        put("HANGMAN", "we're gonna get a?");
        put("KEYBOARD", "Used to input characters into a computer");
        put("MOUSE", "A pointing device for computers");
        put("MONITOR", "A display screen for computers");
        put("DATABASE", "Organized collection of structured information");
        put("VARIABLE", "Named storage that can change during program execution");
        put("FUNCTION", "Apple fritters and pastries will be at the");
        put("NETWORK", "What third years try to desperately do at any event");
        put("PROGRAMMING", "The process of creating computer software");
    }};

    private String wordToGuess;
    private String currentClue;
    private char[] currentGuess;
    private ArrayList<Character> guessedLetters;
    private int wrongGuesses;
    private int maxWrongGuesses = 6;
    private boolean gameOver = false;

    private JPanel mainPanel;
    private JPanel wordPanel;
    private JPanel keyboardPanel;
    private JPanel hangmanPanel;
    private JLabel messageLabel;
    private JLabel clueLabel;
    private JButton[] letterButtons;
    private JButton newGameButton;
    private JLabel keyboardInputLabel;
    
    private Font papyrusFont;
    private final Color BACKGROUND_COLOR = new Color(240, 240, 250);
    private final Color UNUSED_KEY_COLOR = new Color(220, 220, 220);
    private final Color CORRECT_GUESS_COLOR = new Color(144, 238, 144);
    private final Color WRONG_GUESS_COLOR = new Color(255, 160, 160);
    private final Color DISABLED_COLOR = new Color(200, 200, 200);
    
    // Constructor
    public HangmanGame() {
        setTitle("Java Microproject");
        setSize(700, 600); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initializeFonts();
        initializeGame();
        setupGUI();
        addKeyListener(this);
        setFocusable(true);
        requestFocusInWindow();
        
        setVisible(true);
    }
    
    //Try and catch for Papyrus
    private void initializeFonts() {
        try {
            papyrusFont = new Font("Papyrus", Font.BOLD, 22);
            if (!"Papyrus".equals(papyrusFont.getFontName())) {
                papyrusFont = new Font("Comic Sans MS", Font.BOLD, 22);
            }
        } catch (Exception e) {
            papyrusFont = new Font("Serif", Font.BOLD, 22);
        }
    }
 
    private void initializeGame() {
        // Random word selector (or is it?)
        String[] words = WORD_CLUES.keySet().toArray(new String[0]);
        Random random = new Random();
        wordToGuess = words[random.nextInt(words.length)];
        currentClue = WORD_CLUES.get(wordToGuess);
        
        currentGuess = new char[wordToGuess.length()];
        for (int i = 0; i < currentGuess.length; i++) {
            currentGuess[i] = '_';
        }
        
        // Reset game state
        guessedLetters = new ArrayList<>();
        wrongGuesses = 0;
        gameOver = false;
    }
    
    private void setupGUI() {
        mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.setBackground(BACKGROUND_COLOR);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(BACKGROUND_COLOR);

        messageLabel = new JLabel("Welcome to Hangman! Guess a letter using keyboard or buttons.", SwingConstants.CENTER);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        topPanel.add(messageLabel, BorderLayout.NORTH);

        keyboardInputLabel = new JLabel("Physical keyboard input: ENABLED", SwingConstants.CENTER);
        keyboardInputLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        keyboardInputLabel.setForeground(new Color(0, 128, 0));  
        topPanel.add(keyboardInputLabel, BorderLayout.SOUTH);
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(BACKGROUND_COLOR);
        hangmanPanel = new HangmanDrawPanel();
        hangmanPanel.setPreferredSize(new Dimension(200, 200));
        hangmanPanel.setBackground(Color.WHITE);
        hangmanPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        centerPanel.add(hangmanPanel, BorderLayout.WEST);

        JPanel wordCluePanel = new JPanel(new BorderLayout(5, 15));
        wordCluePanel.setBackground(BACKGROUND_COLOR);
        
        // For them clues
        clueLabel = new JLabel("CLUE: " + currentClue, SwingConstants.CENTER);
        clueLabel.setFont(new Font("Arial", Font.BOLD, 16));
        clueLabel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(100, 100, 200), 2),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        clueLabel.setBackground(new Color(230, 230, 255));
        clueLabel.setOpaque(true);
        wordCluePanel.add(clueLabel, BorderLayout.NORTH);
        
        // Word display
        wordPanel = new JPanel();
        wordPanel.setBackground(BACKGROUND_COLOR);
        updateWordDisplay();
        wordCluePanel.add(wordPanel, BorderLayout.CENTER);
        
        centerPanel.add(wordCluePanel, BorderLayout.CENTER);
        
        // V-keyboard
        JPanel keyboardContainerPanel = new JPanel(new BorderLayout(5, 5));
        keyboardContainerPanel.setBackground(BACKGROUND_COLOR);
        keyboardContainerPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY), 
            "Virtual Keyboard (Click letters or use your physical keyboard)"
        ));
        keyboardPanel = new JPanel();
        keyboardPanel.setBackground(BACKGROUND_COLOR);
        createImprovedKeyboard();
        keyboardContainerPanel.add(keyboardPanel, BorderLayout.CENTER);
        
        // New game button
        newGameButton = new JButton("New Game");
        newGameButton.setFont(new Font("Arial", Font.BOLD, 14));
        newGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                initializeGame();
                updateWordDisplay();
                updateClueDisplay();
                updateHangman();
                resetKeyboard();
                messageLabel.setText("New game started! Guess a letter using keyboard or buttons.");
                messageLabel.setFont(new Font("Arial", Font.BOLD, 16)); 
                keyboardInputLabel.setText("Physical keyboard input: ENABLED");
                keyboardInputLabel.setForeground(new Color(0, 128, 0));  
                requestFocusInWindow(); 
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        buttonPanel.add(newGameButton);
        keyboardContainerPanel.add(buttonPanel, BorderLayout.SOUTH);
 
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(keyboardContainerPanel, BorderLayout.SOUTH);
        add(mainPanel);
    }
    
    //In-game keyboard
    private void createImprovedKeyboard() {
        letterButtons = new JButton[26];
        keyboardPanel.setLayout(new BoxLayout(keyboardPanel, BoxLayout.Y_AXIS));
        String[] rows = {
            "QWERTYUIOP",
            "ASDFGHJKL",
            "ZXCVBNM"
        };
        for (String row : rows) {
            JPanel rowPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
            rowPanel.setBackground(BACKGROUND_COLOR);
            
            for (char keyChar : row.toCharArray()) {
                // Letter buttons indexing 
                int index = keyChar - 'A';
                
                JButton keyButton = new JButton(Character.toString(keyChar));
                keyButton.setFont(new Font("Arial", Font.BOLD, 16));
                keyButton.setPreferredSize(new Dimension(50, 40));
                keyButton.setBackground(UNUSED_KEY_COLOR);
                keyButton.setFocusable(false);
                letterButtons[index] = keyButton;
                final char finalKeyChar = keyChar;
                keyButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (!gameOver && !guessedLetters.contains(finalKeyChar)) {
                            processGuess(finalKeyChar);
                        }
                        requestFocusInWindow(); 
                    }
                });
                rowPanel.add(keyButton);
            }
            keyboardPanel.add(rowPanel);
        }
    }
    private void resetKeyboard() {
        for (JButton button : letterButtons) {
            button.setEnabled(true);
            button.setBackground(UNUSED_KEY_COLOR);  
            button.setText(button.getText().charAt(0) + ""); 
        }
    }
    private void updateWordDisplay() {
        wordPanel.removeAll();
        
        JPanel wordContainer = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        wordContainer.setBackground(BACKGROUND_COLOR);
        
        for (char c : currentGuess) {
            JLabel charLabel = new JLabel(String.valueOf(c));
            charLabel.setFont(new Font("Arial", Font.BOLD, 30));
            charLabel.setHorizontalAlignment(SwingConstants.CENTER);
            charLabel.setPreferredSize(new Dimension(35, 45));
            charLabel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.BLACK));
            wordContainer.add(charLabel);
        }
        wordPanel.add(wordContainer);
        wordPanel.revalidate();
        wordPanel.repaint();
    }
    private void updateClueDisplay() {
        clueLabel.setText("CLUE: " + currentClue);
    }
    private void processGuess(char letter) {
        if (gameOver || guessedLetters.contains(letter)) {
            return;
        }
        guessedLetters.add(letter);
        updateButtonForLetter(letter);
        boolean correctGuess = false;
        for (int i = 0; i < wordToGuess.length(); i++) {
            if (wordToGuess.charAt(i) == letter) {
                currentGuess[i] = letter;
                correctGuess = true;
            }
        }
        if (correctGuess) {
            messageLabel.setText("Good guess! '" + letter + "' is in the word.");
            messageLabel.setFont(new Font("Arial", Font.BOLD, 16)); 
            boolean wordComplete = true;
            for (char c : currentGuess) {
                if (c == '_') {
                    wordComplete = false;
                    break;
                }
            }
            if (wordComplete) {
                messageLabel.setText("Congratulations cracka! The word was: " + wordToGuess);
                messageLabel.setFont(papyrusFont); 
                gameOver = true;
                keyboardInputLabel.setText("Physical keyboard input: DISABLED");
                keyboardInputLabel.setForeground(Color.RED);
            }
        } else {
            wrongGuesses++;
            messageLabel.setText("Wrong guess! '" + letter + "' is not in the word. " + 
                                 (maxWrongGuesses - wrongGuesses) + " attempts left.");
            messageLabel.setFont(new Font("Papyrus", Font.BOLD, 22)); 
            
            if (wrongGuesses >= maxWrongGuesses) {
                messageLabel.setText("Game ova! di word na: " + wordToGuess);
                gameOver = true;
                keyboardInputLabel.setText("Physical keyboard input: DISABLED");
                keyboardInputLabel.setForeground(Color.RED);
                // Revelation of the word
                currentGuess = wordToGuess.toCharArray();
                updateWordDisplay();
                disableKeyboard();
            }
        }
        updateWordDisplay();
        updateHangman();
    }
    
    // Guess Indication Dynamics
    private void updateButtonForLetter(char letter) {
        int index = letter - 'A';
        if (index >= 0 && index < letterButtons.length) {
            JButton button = letterButtons[index];
            
            // Check for letter
            boolean inWord = false;
            for (int j = 0; j < wordToGuess.length(); j++) {
                if (wordToGuess.charAt(j) == letter) {
                    inWord = true;
                    break;
                }
            }
            
            //Guess indicator
            if (inWord) {
                button.setBackground(CORRECT_GUESS_COLOR);  
                button.setText(letter + " ✓");
            } else {
                button.setBackground(WRONG_GUESS_COLOR);    
                button.setText(letter + " ✗");
            }
            
            button.setEnabled(false);
        }
    }
    
    //Stop keyboard
    private void disableKeyboard() {
        for (JButton button : letterButtons) {
            button.setEnabled(false);
        }
    }
    
    //Hangman Dynamic Render
    private void updateHangman() {
        hangmanPanel.repaint();
    }
    
    //Physical keyboard
    @Override
    public void keyTyped(KeyEvent e) {
        if (gameOver) {
            return;  
        }
        
        char keyChar = Character.toUpperCase(e.getKeyChar());
        
        //Letter filter
        if (keyChar >= 'A' && keyChar <= 'Z') {
            //Unguessed letter
            if (!guessedLetters.contains(keyChar)) {
                processGuess(keyChar);
            }
        }
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        //Extra, required
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        //Extra, required
    }
    
    //Hangman display panel
    private class HangmanDrawPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setStroke(new BasicStroke(2));
            
            //Dis fit been di gallows
            g2d.drawLine(40, 180, 160, 180); // Base
            g2d.drawLine(60, 180, 60, 20);   // Pole
            g2d.drawLine(60, 20, 120, 20);   // Top
            g2d.drawLine(120, 20, 120, 40);  // Noose
            
            //Hangman Static Render
            if (wrongGuesses >= 1) {
                // Head
                g2d.drawOval(105, 40, 30, 30);
            }
            
            if (wrongGuesses >= 2) {
                // Body
                g2d.drawLine(120, 70, 120, 120);
            }
            
            if (wrongGuesses >= 3) {
                // Left arm
                g2d.drawLine(120, 80, 100, 100);
            }
            
            if (wrongGuesses >= 4) {
                // Right arm
                g2d.drawLine(120, 80, 140, 100);
            }
            
            if (wrongGuesses >= 5) {
                // Left leg
                g2d.drawLine(120, 120, 100, 150);
            }
            
            if (wrongGuesses >= 6) {
                // Right leg
                g2d.drawLine(120, 120, 140, 150);
                
                // X Eyes
                if (wrongGuesses >= maxWrongGuesses) {
                    g2d.drawLine(110, 50, 118, 58);
                    g2d.drawLine(118, 50, 110, 58);
                    g2d.drawLine(122, 50, 130, 58);
                    g2d.drawLine(130, 50, 122, 58);
                }
            }
        }
    }
    
    //this fit been for launch
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new HangmanGame();
            }
        });
    }
}